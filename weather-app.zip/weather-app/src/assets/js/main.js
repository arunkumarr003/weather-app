Date.prototype.customDateString=function(){
    let months=["Jan","Feb","Mar","Apr",
                      "May","Jun","Jul","Aug",
                      "Sep", "Oct","Nov","Dec"]
    return `${this.getDate()} ${months[this.getMonth()]} ${this.getFullYear()}`
}

Date.prototype.getWeekDay=function(){
    let days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
    return days[this.getDay()]
}