import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { CountriesAndStates } from '../models/data.model';
import { DataService } from '../services/data.service';

@Injectable({
  providedIn: 'root'
})
export class ResolveDataService implements Resolve<CountriesAndStates> {
  constructor(private dataService:DataService) { }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) :Observable<CountriesAndStates>|Promise<CountriesAndStates>|any {
      return this.dataService.getCountriesAndStates()
  }


}
