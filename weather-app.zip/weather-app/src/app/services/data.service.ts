import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { CityResponse, CountriesAndStates, CountriesResponse, Country, StateData } from '../models/data.model';
import { Consts } from '../utils/const';
import {map} from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class DataService {
  countries?:Country[]
  // states?:State[]
  constructor(private http:HttpClient) { }
  public countriesAndStates:BehaviorSubject<StateData[]>=new BehaviorSubject<StateData[]>([]);
  

  getCountries():Observable<CountriesResponse>{
    return this.http.get<CountriesResponse>(Consts.COUNTRIES_NOW_SERVER_URL+"/countries/positions").pipe(map((result:CountriesResponse)=>{
      this.countries=result.data
      return result;
    }))
  }

  getCountriesAndStates():Observable<CountriesAndStates>{
    console.log("Calling...")
    return this.http.get<CountriesAndStates>(Consts.COUNTRIES_NOW_SERVER_URL+"/countries/states").pipe(map((result:CountriesAndStates)=>{
      this.countriesAndStates.next(result.data)
      return result
    }))
  }

  getCities(country:string,state:string):Observable<CityResponse>{
    return this.http.post<CityResponse>(Consts.COUNTRIES_NOW_SERVER_URL+"/countries/state/cities",{country,state})
  }

  getCurrentCity():Observable<any>{
    return this.http.get<any>('https://geolocation-db.com/json/').pipe(map((result:any)=>{
        return this.http.get<any>('http://ip-api.com/json/'+result.IPv4)
    }))
  }
}
