import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ERROR_RESPONSE, WeatherData } from '../models/data.model';
import { Consts } from '../utils/const'

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  constructor(private http:HttpClient) { }
  getWeatherData(q:string):Observable<WeatherData>{
    return this.http.get<WeatherData>(Consts.WEATHER_API_URL,{params:{q,appid:Consts.API_ID,units:Consts.units}})
  }
}
