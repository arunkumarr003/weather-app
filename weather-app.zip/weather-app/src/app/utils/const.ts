export class Consts{
     static WEATHER_API_URL="http://api.openweathermap.org/data/2.5/weather"
     static API_ID="90cb68cf3567e9f877e95768ff6c4213"
     static units="metric"
     static COUNTRIES_NOW_SERVER_URL="https://countriesnow.space/api/v0.1"
}