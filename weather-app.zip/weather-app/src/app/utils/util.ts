


export class Util{
    static getWeekDay(day:number):string{
        let days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
        return days[day];
    }
}