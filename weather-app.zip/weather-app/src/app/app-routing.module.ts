import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ResolveDataService } from './resolvers/resolve_data.service';

const routes: Routes = [

  {
    path:"",
    component:AppComponent,
    resolve:{
      countriesAndStates:ResolveDataService
    }
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
