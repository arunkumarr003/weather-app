export interface WeatherData{
    coord:Coord,
    weather:Weather[],
    base:string,
    main:WeatherMainData,
    visibility:number,
    wind:Wind,
    clouds:Clouds,
    dt: string,
    sys: Sys,
    timezone: number,
    id: number,
    name: string,
    cod: string
}

export interface Clouds{
    all:number
}

export interface Wind {
    speed: number,
    deg: number,
    gust: number
}

export interface Sys{
    country: string,
    sunrise: number,
    sunset: number
}

export interface Coord{
    lon:number,
    lat:number
}

export interface Weather{
    id:number,
    main:string,
    description:string,
    icon:string
}

export interface WeatherMainData{
    temp:number,
    feels_like:number,
    temp_min:number,
    temp_max:number,
    pressure:number,
    humidity:number,
    sea_level:number,
    grnd_level:number
}

export interface ERROR_RESPONSE{
    cod:string,
    message:string
}

export interface Country{
    name:string,
    iso2:string,
    long:string,
    lat:string
}

export interface CountriesResponse{
    error:boolean,
    msg:string,
    data:Country[]
}

export interface StateResponse{
    error:boolean,
    msg:string,
    data:StateData
}

export interface CountriesAndStates{
    error:boolean,
    msg:string,
    data:StateData[]
}

export interface StateData{
    name:string,
    iso3:string,
    iso2:string,
    states:State[]
}

export interface State{
    name:string,
    state_code:string
}

export interface CityResponse{
    error:boolean,
    msg:string,
    data:string[]
}