import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {  CityResponse, CountriesAndStates, State, StateData, Weather, WeatherData } from 'src/app/models/data.model';
import { DataService } from 'src/app/services/data.service';
import { WeatherService } from 'src/app/services/weather.service';
// import { Util } from 'src/app/utils/util';
declare var Date:any;
@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit,OnChanges {

  @Input('country')
  country:string=""

  @Input('state')
  state:string=""

  @Input('city')
  q:string=""

  loading:boolean=true
  weatherData?:WeatherData
  errorData?:HttpErrorResponse
  weather?:Weather
  
  date:any
  day:string
  dateString:string
  countriesArray:string[]=[]
  countriesAndStates:StateData[]=[]
  
  
  statesArray:State[]=[]
  cities:string[]=[]
  
  constructor(private weatherService:WeatherService,private dataService:DataService) { 
    // this.q=""
    this.date=new Date()
    this.dateString=this.date.customDateString()
    this.day=this.date.getWeekDay()
    console.log(this.dataService.countriesAndStates);
    
    // this.day=Util.getWeekDay(this.date.getDay())
  }

  ngOnInit(): void {
    this.dataService.countriesAndStates.subscribe(countriesData=>{
        this.countriesAndStates=countriesData;
        this.countriesArray=countriesData.map(d=>d.name);
        if(this.q && this.state && this.country){
          setTimeout(()=>{
            this.setStateArray()
            this.setCityArray()
            this.getWeatherReport()
          },500)
        }
    })
    
    
    this.getWeatherReport();


  }

  ngOnChanges(changes: SimpleChanges): void {
    // if(this.country && this.state && this.q){
    //   this.setStateArray()
    //   this.setCityArray()
    //   this.getWeatherReport()
    // }    
  }

  getWeatherReport(): void{
    this.loading=true
    this.weatherService.getWeatherData(this.q).subscribe((response:WeatherData)=>{
        this.weatherData=response
        this.weather=this.weatherData.weather[0]
        this.errorData=undefined
        console.log(this.weatherData)
    },(error:HttpErrorResponse)=>{
        this.errorData=error
        // alert(this.errorData.error?.message)
        this.loading=false
        this.weatherData=undefined
    },()=>{
       setTimeout(()=>{this.loading=false},100)
    })

    
  }

  setStateArray():void{
    this.countriesAndStates.forEach(cntry=>{
      if(cntry.name===this.country){
        console.log(cntry.states)
        this.statesArray=cntry.states
      }
    })
  }

  setCityArray():void{
    this.dataService.getCities(this.country,this.state).subscribe((resp:CityResponse)=>{
      
      this.cities=resp.data
    },error=>{
      this.cities=[]
    })
  }


  countriesSelect(e:any):void{
    this.country=e.target.value
    this.statesArray=[]
    this.state=""
    this.cities=[]
    this.q=""
    if(this.country){
      console.log(this.country)
      this.setStateArray()
    }
  }

  stateSelect(e:any):void{
    this.state=e.target.value
    this.q=""
    if(this.state){ 
      
      this.setCityArray()
    }else{
      
      this.cities=[]
    }
  }

  citySelect(e:any):void{
    this.q=e.target.value
    this.getWeatherReport()
  }

}
